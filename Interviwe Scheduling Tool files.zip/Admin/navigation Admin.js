window.onload = () => {
  document.getElementById('mainMenuBtn').onclick = () => window.location.href = 'IST Admin Applay list.html';
  document.getElementById('dashboardBtn').onclick = () => window.location.href = 'IST Admin Appointment.html';
  document.getElementById('interviewBtn').onclick = () => window.location.href = 'IST Admin Meeting call.html';
  document.getElementById('insightBtn').onclick = () => window.location.href = 'IST Admin Fix Appointment.html';
  document.getElementById('talentBtn').onclick = () => window.location.href = 'IST Admin Talent .html';
  document.getElementById('generalBtn').onclick = () => window.location.href = 'IST Admin General.html';
  document.getElementById('faqBtn').onclick = () => window.location.href = 'IST Admin FAQ by Applayer.html';
  document.getElementById('settingBtn').onclick = () => window.location.href = 'IST Admin Setting.html';
  document.getElementById('logoutBtn').onclick = () => window.location.href = 'login page.html';
};
