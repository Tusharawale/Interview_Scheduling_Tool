window.onload = () => {
  document.getElementById('mainMenuBtn').onclick = () => window.location.href = 'IST Main Menu.html';
  document.getElementById('dashboardBtn').onclick = () => window.location.href = 'IST Deshboard.html';
  document.getElementById('interviewBtn').onclick = () => window.location.href = 'IST interview.html';
  document.getElementById('insightBtn').onclick = () => window.location.href = 'IST insight.html';
  document.getElementById('talentBtn').onclick = () => window.location.href = 'IST Talent.html';
  document.getElementById('generalBtn').onclick = () => window.location.href = 'IST General.html';
  document.getElementById('faqBtn').onclick = () => window.location.href = 'IST FAQ.html';
  document.getElementById('settingBtn').onclick = () => window.location.href = 'IST Setting.html';
  document.getElementById('logoutBtn').onclick = () => window.location.href = 'login page.html';
};
